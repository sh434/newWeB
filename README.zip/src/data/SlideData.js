
export const SlideData = [
    {
        imageUrl: "https://risingtheme.com/html/demo-newvilla/newvilla/assets/img/blog/blog1.png",
        altText: "blog-img",
        badge: "Business",
        date: "02 Apr 2024",
        comments: "03",
        heading: "The 8 Best Things About Real Estate",
        pargraph: "Business is the activity of making on cing or buying and selling pro  "


    },
    {
        imageUrl: "https://risingtheme.com/html/demo-newvilla/newvilla/assets/img/blog/blog1.png",
        altText: "blog-img",
        badge: "Business",
        date: "02 Apr 2024",
        comments: "03",
        heading: "The 8 Best Things About Real Estate",
        pargraph: "Business is the activity of making on cing or buying and selling pro  "
    },
    {
        imageUrl: "https://risingtheme.com/html/demo-newvilla/newvilla/assets/img/blog/blog1.png",
        altText: "blog-img",
        badge: "Business",
        date: "02 Apr 2024",
        comments: "03",
        heading: "The 8 Best Things About Real Estate",
        pargraph: "Business is the activity of making on cing or buying and selling pro  "
    },
    {
        imageUrl: "https://risingtheme.com/html/demo-newvilla/newvilla/assets/img/blog/blog1.png",
        altText: "blog-img",
        badge: "Business",
        date: "02 Apr 2024",
        comments: "05",
        heading: "The 8 Best Things About Real Estate",
        pargraph: "Business is the activity of making on cing or buying and selling pro  "
    },
    {
        imageUrl: "https://risingtheme.com/html/demo-newvilla/newvilla/assets/img/blog/blog1.png",
        altText: "blog-img",
        badge: "Business",
        date: "02 Apr 2024",
        comments: "06",
        heading: "The 8 Best Things About Real Estate",
        pargraph: "Business is the activity of making on cing or buying and selling pro  "
    },
    {
        imageUrl: "https://risingtheme.com/html/demo-newvilla/newvilla/assets/img/blog/blog1.png",
        altText: "blog-img",
        badge: "Business",
        date: "02 Apr 2024",
        comments: "07",
        heading: "The 8 Best Things About Real Estate",
        pargraph: "Business is the activity of making on cing or buying and selling pro  "
    },
    {
        imageUrl: "https://risingtheme.com/html/demo-newvilla/newvilla/assets/img/blog/blog1.png",
        altText: "blog-img",
        badge: "Business",
        date: "02 Apr 2024",
        comments: "04",
        heading: "The 8 Best Things About Real Estate",
        pargraph: "Business is the activity of making on cing or buying and selling pro  "
    },
    {
        imageUrl: "https://risingtheme.com/html/demo-newvilla/newvilla/assets/img/blog/blog1.png",
        altText: "blog-img",
        badge: "Business",
        date: "02 Apr 2024",
        comments: "05",
        heading: "The 8 Best Things About Real Estate",
        pargraph: "Business is the activity of making on cing or buying and selling pro  "
    },



]