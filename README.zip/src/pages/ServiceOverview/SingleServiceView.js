import React from 'react'
import Dynamic from '../../Components/DynamicBanner/Dynamic'
import './Services.css'


const SingleServiceView = () => {
    return (
        <> 
        <Dynamic
           backgroundImage="/assets/building-view-from-field%201.jpg"
           heading="Single Service View"
           subheading="Learn more about our company and values."
        />
        <div><section className="services__details--section section--padding pt-5 mb-30">
            <div className="container">
                <div className="row">
                    <div className="col-lg-8">
                        <div className="services__details--wrapper">
                            <div className="services__details--thumbnail mb-30">
                                <img src="/assets/property/featured-grid1.jpg" alt="img" style={{ width: "805px" }} />
                            </div>
                            <div className="services__details--content">
                                <div className="services__details--content__step mb-30">
                                    <h2 className="services__details--title">Licensing Compliance</h2>
                                    <p className="services__details--desc">
                                        Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                                        Placeat qui ducimus illum modi? perspiciatis accusamus soluta
                                        perferendis, ad illum, nesciunt, reiciendis iusto et cupidit
                                        Repudiandae provident to consectetur, sapiente, libero iure
                                        necessitatibus corporis nulla voluptate, quisquam aut
                                        perspiciatis? Fugiat labore aspernatur eius, perspiciatis ut
                                        molestiae, delectus rem.
                                    </p>
                                </div>
                                <div className="services__details--info mb-40 d-flex">
                                    <div className="services__details--info__thumbnail position-relative">
                                        <img src="/assets/property/featured-grid3.jpg" alt="img" />
                                        <div className="bideo__play">
                                            <a
                                                className="bideo__play--icon glightbox"
                                                href="https://vimeo.com/115041822"
                                                data-gallery="video"
                                            >
                                                <svg
                                                    width={13}
                                                    height={17}
                                                    viewBox="0 0 13 17"
                                                    fill="none"
                                                    xmlns="http://www.w3.org/2000/svg"
                                                >
                                                    <path
                                                        d="M11.9358 7.28498C12.5203 7.67662 12.5283 8.53339 11.9512 8.93591L1.99498 15.8809C1.33555 16.3409 0.430441 15.8741 0.422904 15.0701L0.294442 1.36797C0.286904 0.563996 1.1831 0.0802964 1.85104 0.527837L11.9358 7.28498Z"
                                                        fill="currentColor"
                                                    />
                                                </svg>
                                                <span className="visually-hidden">Video Play</span>
                                            </a>
                                        </div>
                                    </div>
                                    <div className="services__details--info__content">
                                        <h3 className="services__details--info__title">
                                            Why Licensing Important ?
                                        </h3>
                                        <p className="services__details--info__desc">
                                            Lorem ipsum dolor sit amet, consectetur adipisicin elit sed do
                                            eiusmod tempor incididunt ut labore et{" "}
                                        </p>
                                        <ul className="services__details--info__ui-content">
                                            <li>
                                                <span>
                                                    <svg
                                                        width={13}
                                                        height={14}
                                                        viewBox="0 0 13 14"
                                                        fill="none"
                                                        xmlns="http://www.w3.org/2000/svg"
                                                    >
                                                        <path
                                                            d="M11.9538 2.40018C11.0418 3.23218 10.1538 4.20018 9.28981 5.30418C8.53781 6.25618 7.86181 7.23218 7.26181 8.23218C6.71781 9.12818 6.32181 9.89618 6.07381 10.5362C6.06581 10.5602 6.04981 10.5802 6.02581 10.5962C6.00181 10.6202 5.97381 10.6322 5.94181 10.6322C5.93381 10.6402 5.92581 10.6442 5.91781 10.6442C5.86181 10.6442 5.82181 10.6282 5.79781 10.5962L1.51381 6.24018C1.50581 6.23218 1.60981 6.12818 1.82581 5.92818C2.04181 5.72018 2.25381 5.53218 2.46181 5.36418C2.69381 5.17218 2.81781 5.08418 2.83381 5.10018L5.18581 6.94818C5.87381 6.14018 6.64581 5.34018 7.50181 4.54818C8.78981 3.36418 10.1178 2.35618 11.4858 1.52418C11.5098 1.52418 11.6018 1.63618 11.7618 1.86018L12.0018 2.20818C12.0098 2.24018 12.0098 2.27618 12.0018 2.31618C11.9938 2.34818 11.9778 2.37618 11.9538 2.40018Z"
                                                            fill="currentColor"
                                                        />
                                                    </svg>
                                                </span>{" "}
                                                Research beyond the business plan
                                            </li>
                                            <li>
                                                <span>
                                                    <svg
                                                        width={13}
                                                        height={14}
                                                        viewBox="0 0 13 14"
                                                        fill="none"
                                                        xmlns="http://www.w3.org/2000/svg"
                                                    >
                                                        <path
                                                            d="M11.9538 2.40018C11.0418 3.23218 10.1538 4.20018 9.28981 5.30418C8.53781 6.25618 7.86181 7.23218 7.26181 8.23218C6.71781 9.12818 6.32181 9.89618 6.07381 10.5362C6.06581 10.5602 6.04981 10.5802 6.02581 10.5962C6.00181 10.6202 5.97381 10.6322 5.94181 10.6322C5.93381 10.6402 5.92581 10.6442 5.91781 10.6442C5.86181 10.6442 5.82181 10.6282 5.79781 10.5962L1.51381 6.24018C1.50581 6.23218 1.60981 6.12818 1.82581 5.92818C2.04181 5.72018 2.25381 5.53218 2.46181 5.36418C2.69381 5.17218 2.81781 5.08418 2.83381 5.10018L5.18581 6.94818C5.87381 6.14018 6.64581 5.34018 7.50181 4.54818C8.78981 3.36418 10.1178 2.35618 11.4858 1.52418C11.5098 1.52418 11.6018 1.63618 11.7618 1.86018L12.0018 2.20818C12.0098 2.24018 12.0098 2.27618 12.0018 2.31618C11.9938 2.34818 11.9778 2.37618 11.9538 2.40018Z"
                                                            fill="currentColor"
                                                        />
                                                    </svg>
                                                </span>
                                                Marketing options and rates
                                            </li>
                                            <li>
                                                <span>
                                                    <svg
                                                        width={13}
                                                        height={14}
                                                        viewBox="0 0 13 14"
                                                        fill="none"
                                                        xmlns="http://www.w3.org/2000/svg"
                                                    >
                                                        <path
                                                            d="M11.9538 2.40018C11.0418 3.23218 10.1538 4.20018 9.28981 5.30418C8.53781 6.25618 7.86181 7.23218 7.26181 8.23218C6.71781 9.12818 6.32181 9.89618 6.07381 10.5362C6.06581 10.5602 6.04981 10.5802 6.02581 10.5962C6.00181 10.6202 5.97381 10.6322 5.94181 10.6322C5.93381 10.6402 5.92581 10.6442 5.91781 10.6442C5.86181 10.6442 5.82181 10.6282 5.79781 10.5962L1.51381 6.24018C1.50581 6.23218 1.60981 6.12818 1.82581 5.92818C2.04181 5.72018 2.25381 5.53218 2.46181 5.36418C2.69381 5.17218 2.81781 5.08418 2.83381 5.10018L5.18581 6.94818C5.87381 6.14018 6.64581 5.34018 7.50181 4.54818C8.78981 3.36418 10.1178 2.35618 11.4858 1.52418C11.5098 1.52418 11.6018 1.63618 11.7618 1.86018L12.0018 2.20818C12.0098 2.24018 12.0098 2.27618 12.0018 2.31618C11.9938 2.34818 11.9778 2.37618 11.9538 2.40018Z"
                                                            fill="currentColor"
                                                        />
                                                    </svg>
                                                </span>{" "}
                                                The ability to turnaround consulting
                                            </li>
                                            <li>
                                                <span>
                                                    <svg
                                                        width={13}
                                                        height={14}
                                                        viewBox="0 0 13 14"
                                                        fill="none"
                                                        xmlns="http://www.w3.org/2000/svg"
                                                    >
                                                        <path
                                                            d="M11.9538 2.40018C11.0418 3.23218 10.1538 4.20018 9.28981 5.30418C8.53781 6.25618 7.86181 7.23218 7.26181 8.23218C6.71781 9.12818 6.32181 9.89618 6.07381 10.5362C6.06581 10.5602 6.04981 10.5802 6.02581 10.5962C6.00181 10.6202 5.97381 10.6322 5.94181 10.6322C5.93381 10.6402 5.92581 10.6442 5.91781 10.6442C5.86181 10.6442 5.82181 10.6282 5.79781 10.5962L1.51381 6.24018C1.50581 6.23218 1.60981 6.12818 1.82581 5.92818C2.04181 5.72018 2.25381 5.53218 2.46181 5.36418C2.69381 5.17218 2.81781 5.08418 2.83381 5.10018L5.18581 6.94818C5.87381 6.14018 6.64581 5.34018 7.50181 4.54818C8.78981 3.36418 10.1178 2.35618 11.4858 1.52418C11.5098 1.52418 11.6018 1.63618 11.7618 1.86018L12.0018 2.20818C12.0098 2.24018 12.0098 2.27618 12.0018 2.31618C11.9938 2.34818 11.9778 2.37618 11.9538 2.40018Z"
                                                            fill="currentColor"
                                                        />
                                                    </svg>
                                                </span>{" "}
                                                Customer engagement matters
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="services__details--content__step">
                                    <p className="services__details--desc">
                                        Need something changed or is there something not quite working
                                        the way you envisaged? Is your van a little old and tired and
                                        need refreshing? Lorem Ipsum is simply dummy text of the
                                        printing and typesett industry. Lorem Ipsum has been the
                                        industry’s standard dummy text ever since the 1500s, when an
                                        unknown printer took a galley of type and scrambled it to make a
                                        type specimen book. It has survived only five centuries, but
                                        also the leap into electronic typesetting, remaining essentially
                                        unchanged.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-4">
                        <div className="services__widget">
                            <div className="services__widget--step timing">
                                <h2 className="widget__step--title">Opening Hours</h2>
                                <div className="widget__timing--inner">
                                    <ul className="widget__timing--wrapper">
                                        <li className="widget__timing--list d-flex justify-content-between">
                                            <span className="widget__timing--text">Monday - Friday</span>
                                            <span className="widget__timing--text">9.00 - 20.00</span>
                                        </li>
                                        <li className="widget__timing--list d-flex justify-content-between">
                                            <span className="widget__timing--text">Saturday </span>
                                            <span className="widget__timing--text"> 10.00 - 16.00</span>
                                        </li>
                                        <li className="widget__timing--list d-flex justify-content-between">
                                            <span className="widget__timing--text">Sunday</span>
                                            <span className="widget__timing--text"> 9.30 - 18.00</span>
                                        </li>
                                    </ul>
                                    <a className="widget__timing--btn solid__btn" href="#">
                                        Service details{" "}
                                        <svg
                                            width={16}
                                            height={10}
                                            viewBox="0 0 16 10"
                                            fill="none"
                                            xmlns="http://www.w3.org/2000/svg"
                                        >
                                            <path
                                                d="M15.3138 4.52225L10.8174 0.196665C10.7546 0.134718 10.678 0.0852214 10.5927 0.0513554C10.5073 0.0174894 10.415 0 10.3217 0C10.2284 0 10.1361 0.0174894 10.0508 0.0513554C9.96542 0.0852214 9.88889 0.134718 9.82609 0.196665C9.69402 0.327555 9.62088 0.497837 9.62088 0.674421C9.62088 0.851006 9.69402 1.02128 9.82609 1.15217L13.123 4.32296H1.10886C0.918497 4.33537 0.740424 4.41199 0.610441 4.53743C0.480458 4.66286 0.408203 4.82781 0.408203 4.99911C0.408203 5.17042 0.480458 5.33536 0.610441 5.4608C0.740424 5.58623 0.918497 5.66286 1.10886 5.67526H13.1211L9.8241 8.84783C9.69203 8.97872 9.6189 9.149 9.6189 9.32559C9.6189 9.50217 9.69203 9.67244 9.8241 9.80333C9.88691 9.86528 9.96343 9.91478 10.0488 9.94864C10.1341 9.98251 10.2264 10 10.3197 10C10.4131 10 10.5053 9.98251 10.5907 9.94864C10.676 9.91478 10.7526 9.86528 10.8154 9.80333L15.3138 5.48665C15.4486 5.35524 15.5235 5.18311 15.5235 5.00445C15.5235 4.82579 15.4486 4.65366 15.3138 4.52225Z"
                                                fill="currentColor"
                                            />
                                        </svg>
                                    </a>
                                </div>
                            </div>
                            <div className="services__widget--step">
                                <h2 className="widget__step--title">IMAGE GALLERY</h2>
                                <div className="widget__img--gallery">
                                    <div className="widget__img--gallery__thumbnail mb-20">
                                        <img src="/assets/property/featured-list4.jpg" alt="img" />
                                    </div>
                                    <div className="widget__img--gallery__content">
                                        <h3 className="widget__img--gallery__title">Dental Bridges</h3>
                                        <p className="widget__img--gallery__desc">
                                            Lorem ipsum dolor sit amet, conse adipisicing elit, sed do
                                            eiusmod tempor
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        </div></>
    )
}

export default SingleServiceView