export const citiesData = [
    {
        name: 'California',
        propertiesCount: 13,
        imageUrl: 'assets/property/popular-properties1.png',
    },
    {
        name: 'New York',
        propertiesCount: 22,
        imageUrl: 'assets/property/popular-properties2.png',
    },
    {
        name: 'Texas',
        propertiesCount: 18,
        imageUrl: 'assets/property/popular-properties3.png',
    },
    {
        name: 'Florida',
        propertiesCount: 9,
        imageUrl: 'assets/property/popular-properties4.png',
    },
    {
        name: 'Nevada',
        propertiesCount: 5,
        imageUrl: 'assets/property/popular-properties5.png',
    },
  
];