import React from 'react'
import './Service.css'
const Service = () => {
    return (
        <div className="service-section pt-4">
            <div className='container'>
                <div className='row '>
                    <div className='col-md-4' style={{ padding: '18px' }}>
                        <div className="card" style={{ width: '30rem', backgroundColor: "black" }} >
                            <div className="card-body">
                                <h2 className="text-white">Service Areas</h2>
                                <p className="text-white">
                                    Our aim is to relieve developers and
                                    investors from all the operational
                                    hurdles. We are not just a bunch
                                    of consultants, we are advisors to
                                    developers and investor. We create
                                    ensures its success along with
                                    profitability’s and better return on
                                    investment rather really outstand
                                    -ing investment.
                                </p>
                                <button className=" solid__btn">
                                    Know More
                                </button>
                            </div>
                        </div>

                    </div>
                    <div className='col-md-8'>
                        <div className='row' >
                            <div className="custom-card col-md-2" style={{width:'18rem'}}>
                                <div className="card-content">
                                    <div className="amenities__icone text-center">
                                        <span>
                                            {/* <i className={item.iconClass}></i> */}
                                        </span>
                                    </div>
                                    {/* Replace "fa-star" with your desired icon class */}
                                    <h3 className="card-heading">Card Heading</h3>
                                </div>
                            </div>

                            <div className="custom-card col-md-2" style={{width:'18rem',marginLeft:"18px"}}>
                                <div className="card-content">
                                    <div className="amenities__icone text-center">
                                        <span>
                                            {/* <i className={item.iconClass}></i> */}
                                        </span>
                                    </div>
                                    {/* Replace "fa-star" with your desired icon class */}
                                    <h3 className="card-heading">Card Heading</h3>
                                </div>
                            </div>
                            
                            
                        </div>

                    </div>

                </div>

            </div>
        </div>
    )
}

export default Service
